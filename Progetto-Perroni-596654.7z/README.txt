Per compilare:

gcc -Wall -o server server.c
gcc -Wall -o client client.c

La porta in ascolto del server è la 1919
